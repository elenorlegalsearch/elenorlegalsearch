# Elenor Legal Search: neue Startseite + SEO-Paket

## Inhalt
| Datei | Zweck | Aktion |
|---|---|---|
| index.html | neue Startseite inkl. SEO (Titel, Beschreibung, strukturierte Daten für Google: Website, Organisation, Person, FAQ) | ersetzt die alte Datei |
| assets/v2/ | Design, Animationen, Schriften, Porträtfoto, Logo | neuer Ordner |
| favicon.ico, favicon.svg, apple-touch-icon.png, site.webmanifest | neues ELS-Logo als Icon für Google-Suchergebnisse, Browser-Tabs, iPhone & Android | neu (im Hauptverzeichnis) |
| sitemap.xml | aktualisierte Sitemap für Google | ersetzt die alte Datei |

Nichts anderes wird überschrieben. Unterseiten, Bewerber-Upload, Formulare und Statistik bleiben erhalten.

## Damit „Elenor Legal Search“ bei Google oben erscheint
Die Website liefert jetzt alles, was Google braucht. Google muss die Seite aber noch **gemeldet bekommen**. Das geht nur mit Nikolas Google-Konto:

1. **Google Search Console** (kostenlos, ca. 10 Minuten): Website verifizieren, die Sitemap einreichen und die Indexierung der Startseite beantragen. Der Prompt führt Schritt für Schritt durch.
2. **Google-Unternehmensprofil** (kostenlos, empfohlen): https://business.google.com → Unternehmen „Elenor Legal Search“ anlegen (Kategorie „Personalvermittlung“, Website eintragen). Das sorgt für die Infobox rechts in der Google-Suche.
3. **LinkedIn**: Im LinkedIn-Profil die Website https://www.elenorlegalsearch.com eintragen. Idealerweise auch eine LinkedIn-Unternehmensseite „Elenor Legal Search“ anlegen.

Erfahrungswert: Nach der Einreichung erscheint eine neue Website meist innerhalb weniger Tage bis etwa 2 Wochen bei der Suche nach dem eigenen Namen weit oben. Eine Garantie gibt es dafür nicht, die Entscheidung liegt bei Google.

## Zurück zur alten Version
Über die Git-Historie die vorherigen Versionen von index.html und sitemap.xml wiederherstellen.
